/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.tests.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Test;

import esi.automation.home.mainframe.MainframeClientLocalUsingJSON;
import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;
import esi.automation.home.utils.AutomationUtils;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */

public class JSONSchemaTests {

    static Logger log = Logger.getLogger(JSONSchemaTests.class);

    String jsonSteps = "fixtures/jagacy/data/JsonSteps.json";
    String jsonWithMultipleTestSteps = "fixtures/jagacy/data/JsonWithMultipleSteps.json";
    String jsonTestWith1Step = "fixtures/jagacy/data/JsonTestWith1Step.json";
    String jsonStepsPassingValue = "fixtures/jagacy/data/JsonStepsPassingValue.json";

    @Test
    public void givenValidInput_checkJSONFileExists() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonSteps).getFile());
        assertEquals(file.exists(), true);

    }

    @Test
    public void givenValidInput_checkJSONDataStepsWithSucess() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonSteps).getFile());
        JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader(file));

        assertEquals(jsonArray.size(), 82);

    }

    @Test
    public void givenValidInput_checkJSONElementWithSucess() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonWithMultipleTestSteps).getFile());

        JSONParser jsonParser = new JSONParser();
        Object obj = jsonParser.parse(new FileReader(file));

        JSONObject jsonObject = (JSONObject) obj;
        JSONObject jsonChildObject = (JSONObject) jsonObject.get("testCase");
        String jsonChildcuratorObject = (String) jsonChildObject.get("curator");
        String jsonObjectname = (String) jsonChildObject.get("name");

        JSONObject jsonChildObjectConfiguration = (JSONObject) jsonChildObject.get("configuration");
        String jsonStringScreenshot = (String) jsonChildObjectConfiguration.get("screenshots");

        String jsonStringHost = (String) jsonChildObjectConfiguration.get("host");

        JSONArray testSteps = (JSONArray) jsonChildObject.get("testSteps");
        assertTrue(jsonChildcuratorObject != null);
        assertTrue(jsonObjectname != null);
        assertTrue(jsonStringScreenshot != null);
        assertTrue(jsonStringHost != null);
        assertEquals(testSteps.size(), 82);
        // System.out.println("This is whole - " + jsonObject);
        // System.out.println("This is jsonChildObject - " + jsonChildObject);
        // System.out.println("This is curator - " + jsonChildcuratorObject);
        // System.out.println("This is name - " + jsonObjectname);
        // System.out.println("This is host - " + jsonStringHost);
        // System.out.println("This is testSteps - " + testSteps);

    }

    @Test
    public void givenValidInput_ExecuteParserWithSucess() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonWithMultipleTestSteps).getFile());
        Parser parser = new Parser();
        MainframeTestCase testCase = parser.parse(file);
        assertTrue(testCase.getCurator() != null);
        assertEquals(testCase.getTestSteps().size(), 82);

    }

    public void givenValidInputRun_RunExecuterWithSucess() throws Exception {

        Executer executor = null;
        Parser parser = new Parser();
        File file = new File(jsonTestWith1Step);

        executor = Executer.getInstance(parser.parse(file));
        // String returnJson = executor.execute();
        // assertEquals(returnJson, 82);
    }

    public void givenValidInputRun_BuildResponseAddDateTimeValue() throws Exception {

        // log.info("formattedDate is -" +
        // AutomationUtils.getCurrentDateTime());

        // log.info("localDriveLocationToSaveScreen is -" +
        // localDriveLocationToSaveScreen);

        List<ResponseResult> responseResult = new ArrayList<ResponseResult>();
        ResponseResult r1 = new ResponseResult();
        r1.setRunID("1");
        r1.setResults("sucess");
        r1.setExecutionTime(AutomationUtils.getCurrentDateTimeHrsMillSec());

        ResponseResult r2 = new ResponseResult();
        r2.setRunID("2");
        r2.setResults("sucess");
        r2.setExecutionTime(AutomationUtils.getCurrentDateTimeHrsMillSec());

        ResponseResult r3 = new ResponseResult();
        r3.setRunID("3");
        r3.setResults("fail");
        r3.setExecutionTime(AutomationUtils.getCurrentDateTimeHrsMillSec());
        r3.setValidationFaliure("User ID not found");

        responseResult.add(r1);
        responseResult.add(r2);
        responseResult.add(r3);
        assertEquals(responseResult.size(), 3);
    }

    public void givenValidInputRun_MainframeClientLocalUsingJSON() throws Exception {

        MainframeClientLocalUsingJSON mainframeClientJson = new MainframeClientLocalUsingJSON();
        // mainframeClientJson.readAndExecuteSteps(jsonTestWith1Step);
        mainframeClientJson.readAndExecuteSteps(jsonWithMultipleTestSteps);
    }

    public void givenValidInputRun_TestWriteAtCoOrdinates() throws Exception {

        MainframeClientLocalUsingJSON mainframeClientJson = new MainframeClientLocalUsingJSON();
        // mainframeClientJson.readAndExecuteSteps(jsonTestWith1Step);
        mainframeClientJson.readAndExecuteSteps(jsonStepsPassingValue);
    }
}
