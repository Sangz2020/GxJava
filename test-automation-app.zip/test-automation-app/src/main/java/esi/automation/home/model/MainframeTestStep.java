package esi.automation.home.model;

public class MainframeTestStep {

    private String stepName;
    private Long row;
    private Long column;
    private String value;
    private Long timeInMillis;
    private String keyname;
    private String label;
    private String type;
    private Long offset;
    private Long field_no;
    private Long length;
    private String labelPosition;

    public String getStepName() {

        return stepName;
    }

    public void setStepName(String stepName) {

        this.stepName = stepName;
    }

    public Long getRow() {

        return row;
    }

    public void setRow(Long row) {

        this.row = row;
    }

    public Long getColumn() {

        return column;
    }

    public void setColumn(Long column) {

        this.column = column;
    }

    public String getValue() {

        return value;
    }

    public void setValue(String value) {

        this.value = value;
    }

    public Long getTimeInMillis() {

        return timeInMillis;
    }

    public void setTimeInMillis(Long timeInMillis) {

        this.timeInMillis = timeInMillis;
    }

    public String getKeyname() {

        return keyname;
    }

    public void setKeyname(String keyname) {

        this.keyname = keyname;
    }

    public String getLabel() {

        return label;
    }

    public void setLabel(String label) {

        this.label = label;
    }

    public String getType() {

        return type;
    }

    public void setType(String type) {

        this.type = type;
    }

    public Long getOffset() {

        return offset;
    }

    public void setOffset(Long offset) {

        this.offset = offset;
    }

    public Long getField_no() {

        return field_no;
    }

    public void setField_no(Long field_no) {

        this.field_no = field_no;
    }

    public Long getLength() {

        return length;
    }

    public void setLength(Long length) {

        this.length = length;
    }

    public String getLabelPosition() {

        return labelPosition;
    }

    public void setLabelPosition(String labelPosition) {

        this.labelPosition = labelPosition;
    }

    @Override
    public String toString() {

        return "step:" + this.stepName + ", row:" + this.row + ", col:" + this.column + ", keyname:" + this.keyname
                + ", value:" + this.value + ", label:" + this.label + ", timeinmilli:" + this.timeInMillis;
    }

}
