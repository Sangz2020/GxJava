package esi.automation.home.parser;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.MainframeTestStep;

public class Parser {

    private List<MainframeTestStep> testSteps = new ArrayList<MainframeTestStep>();
    private MainframeTestStep testStep = null;
    private MainframeTestCase testCase = null;
    private HashMap sessionInfo = null;

    static Logger log = Logger.getLogger(Parser.class);

    private JSONArray getJsonElementsFromFile(File jsonFile) throws Exception {

        testCase = new MainframeTestCase();

        JSONParser jsonParser = new JSONParser();
        Object obj = jsonParser.parse(new FileReader(jsonFile));
        JSONObject jsonObject = (JSONObject) obj;
        JSONObject jsonChildObject = (JSONObject) jsonObject.get("testCase");

        String jsonChildName = (String) jsonChildObject.get("name");
        String jsonChildCurator = (String) jsonChildObject.get("curator");

        JSONObject jsonChildObjectConfiguration = (JSONObject) jsonChildObject.get("configuration");
        String jsonStringScreenshot = (String) jsonChildObjectConfiguration.get("screenshots");
        String host = (String) jsonChildObjectConfiguration.get("host");
        String port = (String) jsonChildObjectConfiguration.get("port");

        testCase.setCurator(jsonChildCurator);
        testCase.setName(jsonChildName);
        testCase.setScreenshot(jsonStringScreenshot);
        testCase.setHost(host);
        testCase.setPort(port);

        JSONArray jsonArrayTestSteps = (JSONArray) jsonChildObject.get("testSteps");
        return jsonArrayTestSteps;
    }

    public MainframeTestCase parse(File jsonFile) throws Exception {

        JSONArray jsonArray = getJsonElementsFromFile(jsonFile);

        for (Object obj : jsonArray) {
            JSONObject jsonObj = (JSONObject) obj;
            if (null != jsonObj) {
                testStep = new MainframeTestStep();
                for (Object key : jsonObj.keySet()) {
                    String jsonTestStepKey = (String) key;
                    testStep.setStepName(jsonTestStepKey);
                    JSONObject testStepObj = (JSONObject) jsonObj.get(jsonTestStepKey);
                    testStep.setRow((Long) testStepObj.get("row"));
                    testStep.setColumn((Long) testStepObj.get("column"));
                    testStep.setValue((String) testStepObj.get("value"));
                    testStep.setKeyname((String) testStepObj.get("keyname"));
                    testStep.setLabel((String) testStepObj.get("label"));
                    testStep.setTimeInMillis((Long) testStepObj.get("timeInMillis"));
                    testStep.setLabelPosition((String) testStepObj.get("position"));
                    testStep.setField_no((Long) testStepObj.get("field"));
                    testStep.setOffset((Long) testStepObj.get("offset"));
                    testStep.setLength((Long) testStepObj.get("length"));
                    if (testStep.getStepName().equalsIgnoreCase("wait")) {
                        if (testStep.getRow() != null && testStep.getColumn() != null && testStep.getValue() != null
                                && testStep.getTimeInMillis() != null) {
                            testStep.setType(Keywords.TEST_STEP_WAIT_FOR_CORDINATE);
                        } else if (testStep.getTimeInMillis() != null && null == testStep.getRow()) {
                            testStep.setType(Keywords.TEST_STEP_WAIT_FOR_TIME);
                        }
                    } else if (testStep.getStepName().equalsIgnoreCase("input")) {
                        if (null != testStep.getOffset() && null != testStep.getField_no()
                                && null != testStep.getLength()) {
                            testStep.setType(Keywords.TEST_STEP_WRITE_AT_FIELD);
                        } else if (null == testStep.getLabel() && null == testStep.getKeyname()) {
                            testStep.setType(Keywords.TEST_STEP_WRITE_AT_CORDINATE);
                        } else if (null != testStep.getKeyname()) {
                            testStep.setType(Keywords.TEST_STEP_SEND_KEY_NAME);
                        } else if (null == testStep.getKeyname() && null != testStep.getLabel()
                                && null != testStep.getValue()) {
                            if (null == testStep.getLabelPosition())
                                throw new Exception("Label position should be defined : " + testStep.getValue());
                            testStep.setType(Keywords.TEST_STEP_WRITE_AT_LABEL);
                        } else {
                            throw new Exception("Error : Configuration has gone wrong with this step - "
                                    + testStep.toString());
                        }
                    }
                    testSteps.add(testStep);
                }
            }
        }

        testCase.setTestSteps(testSteps);
        return testCase;
    }

}
