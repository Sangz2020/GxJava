package esi.automation.home.parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.jagacy.Field;
import com.jagacy.Key;
import com.jagacy.Session3270;
import com.jagacy.util.JagacyException;
import com.jagacy.util.JagacyProperties;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.MainframeTestStep;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.utils.AutomationUtils;
import esi.automation.home.utils.GrabScreenShots;

public class Executer extends Session3270 {

    static Logger log = Logger.getLogger(Executer.class);

    private static Executer executer = null;
    private JagacyProperties props;
    ResourceBundle configuration = null;
    MainframeTestCase testCase = null;

    List<MainframeTestStep> testSteps = null;
    List<ResponseResult> responseResultList = new ArrayList<ResponseResult>();

    private Executer(MainframeTestCase testCase) throws JagacyException, IOException {

        super("Test Execution");
        // log.info("Begin loading properties");
        this.testCase = testCase;

        props = getProperties();
        loadProps();
        Enumeration e = configuration.getKeys();
        while (e.hasMoreElements()) {
            String key = (String) e.nextElement();
            String value = configuration.getString(key);
            props.set(key, value);
        }

        if (testCase.getScreenshot() != null && testCase.getScreenshot().equalsIgnoreCase("on")) {
            props.set("window", "true");
        } else {
            props.set("window", "false");
        }

        if (testCase.getHost() != null) {
            props.set("jagacy.host", testCase.getHost());
        } else {
            throw new JagacyException("Error Processing JSON Data, Host information incorrect !.");
        }

        if (testCase.getPort() != null) {
            props.set("jagacy.port", testCase.getPort());
        } else {
            throw new JagacyException("Error Processing JSON Data, Port information incorrect !.");
        }

        // log.info("Get Property window - " + props.get("window"));
        // log.info("End loading properties");
    }

    public static Executer getInstance(MainframeTestCase testCase) throws Exception {

        if (null == testCase)
            throw new Exception("stepList object is null");
        if (null == executer) {
            executer = new Executer(testCase);
            executer.testSteps = testCase.getTestSteps();
            return executer;
        } else {
            return executer;
        }
    }

    public List<ResponseResult> execute() throws JagacyException {

        try {
            this.open();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.close();
        }
        return responseResultList;
    }

    @Override
    protected boolean logon() throws JagacyException {

        String validationFaliure = null;

        int index = 0;
        for (MainframeTestStep testStep : this.testSteps) {
            index++;
            // log.info("Executing - Steps Number - " + index + " - " +
            // testStep.getStepName());

            try {
                Thread.currentThread().sleep(1000);
            } catch (InterruptedException e) {
                validationFaliure = e.getLocalizedMessage();
            }
            switch (testStep.getType()) {
            case Keywords.TEST_STEP_WAIT_FOR_CORDINATE:
                String fieldValue = getFieldValue(testStep.getValue());

                props.set(("index" + index + ".wait.row"), Long.toString(testStep.getRow()));
                props.set(("index" + index + ".wait.column"), Long.toString(testStep.getColumn()));
                props.set(("index" + index + ".wait.value"), fieldValue);
                props.set(("index" + index + ".timeout.seconds"), Long.toString(testStep.getTimeInMillis()));
                try {
                    Thread.currentThread().sleep(1000);
                } catch (InterruptedException e) {
                    validationFaliure = e.getLocalizedMessage();
                }
                waitForPosition("index" + index + ".wait", "index" + index + ".timeout.seconds");
                break;
            case Keywords.TEST_STEP_WAIT_FOR_TIME:
                props.set("index" + index + ".timeout.seconds", Long.toString(testStep.getTimeInMillis()));
                waitForChange("index" + index + ".timeout.seconds");
                break;
            case Keywords.TEST_STEP_WRITE_AT_CORDINATE:

                props.set(("index" + index + ".entry.row"), Long.toString(testStep.getRow()));
                props.set(("index" + index + ".entry.column"), Long.toString(testStep.getColumn()));
                props.set(("index" + index + ".entry.value"), testStep.getValue());
                writePosition(
                        "index" + index + ".entry",
                        isParameterized(testStep.getValue()) ? getValueForParam(testStep.getValue()) : testStep
                                .getValue());
                break;
            case Keywords.TEST_STEP_WRITE_AT_LABEL:
                if (testStep.getLabelPosition().equalsIgnoreCase("after")) {
                    if (testStep.getLabel().startsWith("%") && testStep.getLabel().endsWith("%")) {
                        writeAfterLabel(
                                getFieldFullTextContains(testStep.getLabel()),
                                isParameterized(testStep.getValue()) ? getValueForParam(testStep.getValue()) : testStep
                                        .getValue());
                    } else {
                        writeAfterLabel(
                                testStep.getLabel(),
                                isParameterized(testStep.getValue()) ? getValueForParam(testStep.getValue()) : testStep
                                        .getValue());
                    }
                } else if (testStep.getLabelPosition().equalsIgnoreCase("before")) {
                    if (testStep.getLabel().startsWith("%") && testStep.getLabel().endsWith("%")) {
                        writeBeforeLabel(
                                getFieldFullTextContains(testStep.getLabel()),
                                isParameterized(testStep.getValue()) ? getValueForParam(testStep.getValue()) : testStep
                                        .getValue());
                    } else {
                        writeBeforeLabel(
                                testStep.getLabel(),
                                isParameterized(testStep.getValue()) ? getValueForParam(testStep.getValue()) : testStep
                                        .getValue());
                    }
                } else {
                    validationFaliure = "Position should be defined for writting after/before  label : "
                            + testStep.getValue();
                    throw new JagacyException("Position should be defined for writting after/before  label : "
                            + testStep.getValue());
                }
                break;
            case Keywords.TEST_STEP_WRITE_AT_FIELD:
                props.set(("index" + index + ".field"), Long.toString(testStep.getField_no()));
                props.set(("index" + index + ".offset"), Long.toString(testStep.getOffset()));
                props.set(("index" + index + ".length"), Long.toString(testStep.getLength()));
                writeField(
                        "index" + index,
                        isParameterized(testStep.getValue()) ? getValueForParam(testStep.getValue()) : testStep
                                .getValue());
                break;
            case Keywords.TEST_STEP_SEND_KEY_NAME:
                String keyValue = testStep.getKeyname().toUpperCase();
                // TODO Send key values here directly.
                if (testStep.getKeyname().equalsIgnoreCase("ENTER")) {
                    writeKey(Key.ENTER);
                } else if (testStep.getKeyname().equalsIgnoreCase("PF5")) {
                    writeKey(Key.PF5);
                }
                break;
            default:
                validationFaliure = "Invalid day of the week ";
                throw new IllegalArgumentException("Invalid day of the week: ");
            }

            log.info("Processing - Step - " + index + " - " + testStep.getStepName());

            String urlToScreenShot = null;

            if (testCase != null && testCase.getScreenshot().equalsIgnoreCase("on")) {
                try {
                    urlToScreenShot = GrabScreenShots.setScreenImage(index);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    addResponseResult(Integer.toString(index), "sucess", urlToScreenShot, e.getLocalizedMessage());
                    e.printStackTrace();
                }
            }
            addResponseResult(Integer.toString(index), "sucess", urlToScreenShot, null);
        }

        return true;
    }

    // Close jagacy processor terminal.
    @Override
    public void logoff() throws JagacyException {

        // this.close();
    }

    public void loadProps() throws IOException {

        configuration = ResourceBundle.getBundle("fixtures/jagacy/properties/jagacy");
    }

    private String getFieldFullTextContains(String value) throws JagacyException {

        String searchValue = value.replaceAll("%", " ").trim();
        Field field = null;
        Field[] fields = readFields();
        for (Field f : fields) {
            if (f.getValue().toUpperCase().contains(searchValue.toUpperCase())) {
                field = f;
            }
        }
        String val = field.getValue();
        return field.getValue();
    }

    private boolean isParameterized(String fieldValue) {

        if (fieldValue.startsWith("${") && fieldValue.endsWith("}")) {
            return true;
        } else {
            return false;
        }
    }

    private String getValueForParam(String param) throws JagacyException {

        props.set("acptcode.field", "45");
        props.set("acptcode.offset", "1");
        props.set("acptcode.length", "1");
        return readField(param.substring(2, param.length() - 1));
    }

    private void addResponseResult(String runID, String results, String urlToScreenShot, String validationFaliure) {

        ResponseResult responseResult = new ResponseResult();
        responseResult.setExecutionTime(AutomationUtils.getCurrentDateTimeHrsMillSec());
        responseResult.setResults(results);
        responseResult.setRunID(runID);
        if (urlToScreenShot != null) {
            responseResult.setUrlToScreenShot(urlToScreenShot);
        }
        if (validationFaliure != null) {
            responseResult.setValidationFaliure(validationFaliure);
        }

        responseResultList.add(responseResult);

    }

    private String getFieldValue(String fieldData) throws JagacyException {

        String fieldValue = null;
        if (fieldData.startsWith("${") && fieldData.endsWith("}")) {
            fieldValue = getValueForParam(fieldData);
        } else {
            fieldValue = fieldData;
        }
        return fieldValue;
    }
}
