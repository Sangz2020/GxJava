/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.mainframe;

import java.io.FileInputStream;

import org.apache.commons.net.ftp.FTPClient;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class MainframeFTPJobHandle {

    public static void executeJCLJob() {

        String serverName = "mainframe.regioname.N30";
        String userName = "username";
        String password = "242ffs";
        FTPClient ftp = new FTPClient();
        // Connect to the server
        try {
            ftp.connect(serverName);
            String replyText = ftp.getReplyString();
            System.out.println(replyText);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Login to the server
        try {
            ftp.login(userName, password);
            String replyText = ftp.getReplyString();
            System.out.println(replyText);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Tell server that the file will have JCL records
        try {
            ftp.site("filetype=jes");
            String replyText = ftp.getReplyString();
            System.out.println(replyText);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Submit the job from the text file.Use \\ to avoid using escape
        // notation
        try {
            FileInputStream inputStream = new FileInputStream(
                    "C://esi/ws/Git/git/testautomationapp/src/test/resources/jcljob.txt");
            ftp.storeFile(serverName, inputStream);
            String replyText = ftp.getReplyString();
            System.out.println(replyText);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Quit the server
        try {
            ftp.quit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
