/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class AutomationUtils {

    public static String getCurrentDateTime() {

        final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDateTime = dateFormat.format(new Date());
        return currentDateTime;
    }

    public static String getCurrentDateTimeHrsMillSec() {

        final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:sss");
        String currentDateTime = dateFormat.format(new Date());
        return currentDateTime;
    }
}
