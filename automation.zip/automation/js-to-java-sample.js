var js2java = require('js-to-java');
var java = require('java');

java.classpath.push("gson-2.6.2.jar");
java.classpath.push("jagacy3270.jar");
java.classpath.push("json-simple-1.1.1.jar");

var javaLangSystem = java.import('java.lang.System');
var Session3270 = java.import("com.jagacy.Session3270");
var Exception = java.import("com.jagacy.util.JagacyException");
var Props = java.import("com.jagacy.util.JagacyProperties");
var JSONObject = java.import("org.json.simple.JSONObject");
var Gson = java.import("com.google.gson.Gson");
var JavaMainframeTestcase = java.import("esi.automation.home.model.MainframeTestCase");
// Java: com.java.Object o = new com.java.Object();
//var javaObj = js2java('org.json.simple.JSONObject', { foo: 'bar' });
//console.log(javaObj);


var gson = new Gson();

var str = '{"SESSION_NAME": "NodeToJagacy", "HOST_PROP_NAME": "mcfl1g05.medco.com", "HOST_CONTEXT_NAME" : "jagacyHost"}';
//var jsonObj = JSON.parse(str);

//console.log(eval(jsonObj));
props = java.callMethodSync(gson, "fromJson",str ,Props.class);
console.log(props);
console.log(eval(props));