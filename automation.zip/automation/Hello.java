var bool = java.instanceOf(json, "org.json.simple.JSONObject");
console.log(bool);

var jsonObj = {};
function readJSonTestCase(jsonFile) {
    fs.readFile(jsonFile, 'utf8',readJson)
    readJson(jsonFile);

}
function readJson(err,data) {
    if (err) {
        return err;
    }
    return data;
}

try {
    jagacyObj.setUpSession();
} catch (Exception) {
}

var parser = java.newInstanceSync("esi.automation.home.parser.Parser");
//var jagacyObj = java.newInstanceSync("Jagacy");


try {

    java.callMethodSync(javaParser, "parse", JSONObject,  function(err, results) {
        if(err) { console.error(err); return; }
        console.log(results);
    });

} catch (Exception ) {

}

var result = java.callMethodSync(javaParser, "parse", JSONObject);
console.log(result);


String.prototype.escapeSpecialChars = function() {
    return this.replace(/\\n/g, "\\n")
        .replace(/\\'/g, "")
        .replace(/\\"/g, '')
        .replace(/\\&/g, "")
        .replace(/\\r/g, "")
        .replace(/\\t/g, "")
        .replace(/\\b/g, "")
        .replace(/\\f/g, "")
        .replace(/\\n/g, "");
};
var json = fs.readFileSync('testcase.json', "utf8");
var jsonObj = JSON.parse(json);
console.log("jsonString ============== >> "+jsonString);
//var ecapedJSONString = jsonString.escapeSpecialChars();

var jSONObject = new JSONObject();
//{ $class: 'com.test.Object', { 'foo': 'bar' } };

//jSONObject = js2java('org.json.simple.JSONObject', ecapedJSONString );

//console.log(js2java('org.json.simple.JSONObject', ecapedJSONString ));
//JSONObject = java.newInstanceSync('org.json.simple.JSONObject');

//console.log(JSONObject);