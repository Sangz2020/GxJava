/**
 * Created by sangz-pc on 4/1/2017.
 */
'use strict'
var java = require('java');
var path = require('path');
var fs = require("fs");

java.classpath.push("jagacy3270.jar");
java.classpath.push("java/test/commons-lang3-3.1.jar");
java.classpath.push("json-simple-1.1.1.jar");
java.classpath.push("test-automation-app.jar");
java.classpath.push("log4j-1.2.16.jar");
java.classpath.push("rt.jar");

var javaLangSystem = java.import('java.lang.System');
var Session3270 = java.import("com.jagacy.Session3270");
var Exception = java.import("com.jagacy.util.JagacyException");

//var Props = java.import("com.jagacy.util.JagacyProperties");
//var JSONObject = java.import("org.json.simple.JSONObject");
var JavaParser = java.import("esi.automation.home.parser.Parser");
var Executer = java.import("esi.automation.home.parser.Executer");
var ResponseResult = java.import("esi.automation.home.model.ResponseResult");
var EachStepResponseResult = java.import("esi.automation.home.model.EachStepResponseResult");
var Javafile =  java.import('java.io.File');


var javaParser = java.newInstanceSync("esi.automation.home.parser.Parser");
var jagacyException = new Exception("JagacyException");
var javafile = new Javafile('testcase.json');
try {

    var mainframeTestcase = java.callMethodSync(javaParser, "parse", javafile);

} catch(jagacyException) {
    console.error("Exception occurred during Parsing");
    console.error(java.callMethodSync("jagacyException",));

}

try {

    var executerInstance = java.callStaticMethodSync("esi.automation.home.parser.Executer", "getInstance", mainframeTestcase);
    responseResult = java.callMethodSync(executerInstance, "execute");

} catch(jagacyException) {
    console.error("Exception occurred during execution");
}
var responseResult = new ResponseResult();
var eachStepResponseResult = new  EachStepResponseResult();
var responseResultList = java.newInstanceSync("java.util.ArrayList");
responseResultList = java.callMethodSync(responseResult, "getResponseResultList");
var length = responseResultList.sizeSync();
if(length > 0) {
    for (var i = 0; i < length; i++) {
        eachStepResponseResult = responseResultList[i];
        var runId = java.callMethodSync(eachStepResponseResult, "getRunID");
        var executionTime = java.callMethodSync(eachStepResponseResult, "getExecutionTime");
        var results = java.callMethodSync(eachStepResponseResult, "getResults");
        var urlToScreenShot = java.callMethodSync(eachStepResponseResult, "getUrlToScreenShot");
        var validationFaliure = java.callMethodSync(eachStepResponseResult, "getValidationFaliure");

        console.log("eachStepResponseResult  ==> \nrunId " + runId + " " + " \nexecutionTime " + executionTime + " " + " \nresults " + results
            + " \nurlToScreenShot " + urlToScreenShot + " \nvalidationFaliure " + validationFaliure);

    }
} else {
    console.log("responseResultList Size ==> "+length);
}
var sessionData = java.newInstanceSync("java.util.HashMap");
sessionData = java.callMethodSync(responseResult, "getSessionData");
var size = java.callMethodSync(sessionData, "size");
console.log("sessionData.size  ==> "+size);

