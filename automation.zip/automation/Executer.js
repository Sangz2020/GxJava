
'use strict'
var java = require('java');
var path = require('path');
var fs = require("fs");
var help = require("./node-to-jagacy");

java.classpath.push("gson-2.6.2.jar");
java.classpath.push("jagacy3270.jar");
java.classpath.push("java/test/commons-lang3-3.1.jar");
java.classpath.push("json-simple-1.1.1.jar");
java.classpath.push("test-automation-app.jar");
//java.classpath.push("log4j-1.2.16.jar");

//var javaLangSystem = java.import('java.lang.System');
var Session3270 = java.import("com.jagacy.Session3270");
var Exception = java.import("com.jagacy.util.JagacyException");
var Props = java.import("com.jagacy.util.JagacyProperties");
/*
var Gson = java.import("com.google.gson.Gson");
var gson = new Gson();
*/


function Executer (testcase) {
    this.testcase = testcase;
}
var session;
var json = fs.readFileSync('properties.json','utf8');
var str = JSON.stringify(json);
//var props = java.callMethodSync(gson, "fromJson",str ,Props.class);
var response;
Executer.prototype.execute = function () {
    console.log("execute");
    try {
        session = new Session3270("SESSION_NAME");

    }catch (Exception){
    console.error("Could not set up Session3270"+Exception);
    }

};
var executer = new Executer(help.testcase());
executer.execute();

//
