import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import com.jagacy.Key;
import com.jagacy.Session3270;
import com.jagacy.util.JagacyException;

public class NodeJava extends Session3270 {

   
    NodeJava() throws JagacyException {
        super("NodeJava",loadProps());
        //host, port, "IBM-3278-2", false
    }

    private static Properties loadProps() {
    	Properties properties = new Properties();
    	try {
			File file = new File("E:\\work\\JagacyHelper\\src\\example2.properties");
			FileInputStream fileInput = new FileInputStream(file);
			
			properties.load(fileInput);
			fileInput.close();

			Enumeration enuKeys = properties.keys();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String value = properties.getProperty(key);
				System.out.println(key + ": " + value);
				properties.put(key, value);
			}
			properties.put("jagacy.host", "teague-tammvs1.tamu.edu");
			properties.put("jagacy.port", "992");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties;
	}

	// Log onto the mainframe.
    protected boolean logon() throws JagacyException {
	
        // Wait 30 seconds
        waitForChange(30000);

        writePosition(23, 1, "TEST");
        writePosition(24, 1, "test");

        // Enter userid/password
        writeKey(Key.ENTER);

        // Wait 30 seconds
        waitForChange(30000);

        return true;
    }


    // Logoff the mainframe.
    protected void logoff() throws JagacyException {
	
        writePosition(20, 20, "=x");

        writeKey(Key.ENTER);

        // Wait 30 seconds
        waitForChange(30000);
    }


    private String getData() throws JagacyException {
        return readPosition(12, 12, 1000);
    }


    public static void main(String args[]) {
	
        // Show a session window
        System.setProperty("NodeJava.window", "true");
		
        // Create the screen scraper
        NodeJava s;
		try {
			s = new NodeJava();
			s.open();
			// Print the data
			System.out.println(s.getData());
			s.close();

		} catch (JagacyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
      
		
    
        System.exit(0);
    }
}		