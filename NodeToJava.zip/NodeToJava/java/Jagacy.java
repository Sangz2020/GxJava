
import java.io.IOException;
import java.util.Properties;

import com.jagacy.Session3270;
import com.jagacy.util.JagacyException;
import com.jagacy.util.JagacyProperties;

public class Jagacy {
	
	protected Session3270 session;
	private Properties props;
	private JagacyProperties jagacyprops;
	protected final static String SESSION_NAME = "NodeToJava";
	protected final static String HOST_PROP_NAME = "jagacy.host";
	protected final static String HOST_CONTEXT_NAME = "jagacyHost";
	protected String host = "teague-tammvs1.tamu.edu";
	protected Boolean visible = true;
	public Jagacy() throws JagacyException {
		/*
			props = new Properties();
			props.put("jagacy.host", "teague-tammvs1.tamu.edu");
			props.put("jagacy.port", "992");
			jagacyprops =  new JagacyProperties(SESSION_NAME, props);*/

		
	}
	
	public void setUpSession() {
	    System.setProperty(SESSION_NAME+".window", true);
	    System.setProperty(HOST_PROP_NAME, "teague-tammvs1.tamu.edu");
	    System.setProperty("jagacy.port", "992");
	    try{
	    	
	        session = new Session3270(SESSION_NAME);
	    }catch (JagacyException je){
	        throw new RuntimeException("Could not set up Session3270", je);
	    }
	   
	}

	public void startApplication() {
	        try{
	            session.open();
	            try {
                                    Thread.currentThread();
                                    Thread.sleep(50000);
                                } catch (InterruptedException e) {
                                    System.out.println(e);
                                }
	        }catch(JagacyException je){
	        	
	            throw new RuntimeException("Could not connect to host '"+host+"'",je );
	        }
	    }

	
	
	protected void tearDownSession(){
	    if (session != null) {
	        try {
	            session.close();
	        } catch (JagacyException e) {
	            System.err.println("Trouble closing Session3270 connection");
	            e.printStackTrace();
	        }
	    }
	}
	
	public static void main(String[] args) throws JagacyException, IOException {
		Jagacy jag = new Jagacy();
		jag.setUpSession();
		jag.startApplication();
	}

}
